#!/bin/bash
PROBCOMMAND=prob

# Shell wrapper for PROBCOMMAND

export TRAILSTKSIZE=1M

echo "Running ProB"
#echo `readlink "$0"` 

# dirname
if [ -h "$0" ]
then
    realname=`readlink "$0"`
    dirname=`dirname "$realname"`
else
    dirname=`dirname "$0"`
fi

ulimit -d unlimited

echo "Directory: $dirname"
#cd $dirname
#ls
echo "$dirname/$PROBCOMMAND" $*
"$dirname/$PROBCOMMAND" $*
