The B Machines in this directory are taken from the book:
    The B-Method: An Introduction
    (Editor Palgrave, ISBN 0-33-79284-X, Year 2002)
by Steve Schneider.
The source files for all machines, as well as sample pages
of the book, can be found at:
    http://www.palgrave.com/science/computing/schneider/
    
These machines are distributed with kind permission by
Steve Schneider, and have been tested with ProB. In some
circumstances, minor changes were made to the machines to
make them more suitable for use with ProB.
    
 