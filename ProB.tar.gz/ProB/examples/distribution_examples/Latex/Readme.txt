This is a small test highlighting ProB's Latex processing capabilities and generating
a documentation PDF at the same time.

 - update the Makefile so that PROBCLI points to your probcli binary,
   DOT points to the dot command from the GraphViz package, and
   SFDP points to the sfdp command from the GraphViz package
 - type make this should generate various figures in the figure folder and the file prob_latex_doc.pdf